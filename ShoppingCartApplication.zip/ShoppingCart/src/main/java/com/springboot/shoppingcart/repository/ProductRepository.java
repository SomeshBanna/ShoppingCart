package com.springboot.shoppingcart.repository;

import org.springframework.data.repository.CrudRepository;

import com.springboot.shoppingcart.entities.Product;

public interface ProductRepository extends CrudRepository<Product, Integer> {

	

}
