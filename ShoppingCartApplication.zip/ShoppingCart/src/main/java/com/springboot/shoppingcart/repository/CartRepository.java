package com.springboot.shoppingcart.repository;

import org.springframework.data.repository.CrudRepository;

import com.springboot.shoppingcart.entities.Cart;

public interface CartRepository extends CrudRepository<Cart,Integer>{

	

}
