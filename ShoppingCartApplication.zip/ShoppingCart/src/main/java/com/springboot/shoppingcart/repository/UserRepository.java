package com.springboot.shoppingcart.repository;



import org.springframework.data.repository.CrudRepository;

import com.springboot.shoppingcart.entities.User;


public interface UserRepository extends CrudRepository<User, Integer> {

}